﻿namespace webproje.Models.Siniflar
{
    internal interface IEnumarable
    {
    }
}